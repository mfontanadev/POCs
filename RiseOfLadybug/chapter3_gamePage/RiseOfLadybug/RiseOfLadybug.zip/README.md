
## App "Rise of ladybug" (chapter3_gamepage)

This section is the third and last iteration. You can see the hole life cycle game. I hope you can use it as a game template.

See root path for more details at:   [https://github.com/mfontanadev/POCs/tree/master/RiseOfLadybug](https://github.com/mfontanadev/POCs/tree/master/RiseOfLadybug)

## Contact

* site: [https://mfontanadev.github.io](https://mfontanadev.github.io)

* twitter: [https://twitter.com/mfontanadev](https://twitter.com/mfontanadev)

* git: [https://github.com/mfontanadev](https://github.com/mfontanadev)

* linkedin: [https://www.linkedin.com/in/mauricio-fontana-8285681b/?originalSubdomain=ar](https://www.linkedin.com/in/mauricio-fontana-8285681b/?originalSubdomain=ar)


