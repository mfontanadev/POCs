1.0.3 / 2016-18-10
===================
  * deps: ControlCanvas@3.6
    - Fix: Mouse not working when canvas is scaled
    - Refactor: no more canvas, it was replace for canvasEx, this solved mouse scale problems

  * deps: ChLib@1.1
    - Fix: ChCanvas class now has m_scaleX, m_scaleY setted properly.

1.0.2 / 2016-09-05
===================
  * deps: ControlCanvas@3.5
    - Fix: onMouseDown loss focus if we touch outside the control.

  * deps: chlib
	- Add: drawImageRotationTransparentScaledPivot function.
	- Add: chVector class.
	- Add: chCanvas class (provides canvas utilities like resizing)
	- Add: getCurrentHostname function.

  * Refactor over keyboardManager.js
  
  * Refactor over mouseManager.js
  
  * Refactor over soundManager.js
  
1.0.1 / 2016-03-03
===================
  * NO HISTORY INFORMATION FOR THIS VERSION.
  * Initial release
  
ENTRY EXAMPLES TO USE IN VERSION LOG
  * Fix: this is a fix entry

  * deps: file@n.n.n
    - Fix example 1
    - Fix example 2

